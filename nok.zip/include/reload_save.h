#ifndef GUARD_RELOAD_SAVE_H
#define GUARD_RELOAD_SAVE_H

void ReloadSave(void);

#endif // GUARD_RELOAD_SAVE_H
