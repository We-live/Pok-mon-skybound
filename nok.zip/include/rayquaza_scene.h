#ifndef GUARD_RAYQUAZA_SCENE_H
#define GUARD_RAYQUAZA_SCENE_H

#include "main.h"

void DoRayquazaScene(u8 animId, bool8 endEarly, MainCallback exitCallback);

#endif // GUARD_RAYQUAZA_SCENE_H
