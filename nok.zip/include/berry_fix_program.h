#ifndef GUARD_BERRY_FIX_PROGRAM_H
#define GUARD_BERRY_FIX_PROGRAM_H

void CB2_InitBerryFixProgram(void);

#endif // GUARD_BERRY_FIX_PROGRAM_H
