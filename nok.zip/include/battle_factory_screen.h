#ifndef GUARD_BATTLE_FACTORY_SCREEN_H
#define GUARD_BATTLE_FACTORY_SCREEN_H

void DoBattleFactorySelectScreen(void);
void DoBattleFactorySwapScreen(void);

#endif // GUARD_BATTLE_FACTORY_SCREEN_H
