#ifndef GUARD_BATTLE_DEBUG_H
#define GUARD_BATTLE_DEBUG_H

void CB2_BattleDebugMenu(void);

#endif // GUARD_BATTLE_DEBUG_H
