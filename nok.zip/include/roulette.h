#ifndef GUARD_ROULETTE_H
#define GUARD_ROULETTE_H

void PlayRoulette(void);

#endif // GUARD_ROULETTE_H
