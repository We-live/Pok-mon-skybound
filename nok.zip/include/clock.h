#ifndef GUARD_CLOCK_H
#define GUARD_CLOCK_H

// TODO: time of day and seconds in a day defines

void InitTimeBasedEvents(void);
void DoTimeBasedEvents(void);
void FormChangeTimeUpdate();

#endif // GUARD_CLOCK_H
