#ifndef GUARD_BIRCH_PC_H
#define GUARD_BIRCH_PC_H

const u8 *GetPokedexRatingText(u32 count);

#endif // GUARD_BIRCH_PC_H
