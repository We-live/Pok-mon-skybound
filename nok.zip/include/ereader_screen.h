#ifndef GUARD_EREADER_SCREEN_H
#define GUARD_EREADER_SCREEN_H

void CreateEReaderTask(void);

#endif // GUARD_EREADER_SCREEN_H
