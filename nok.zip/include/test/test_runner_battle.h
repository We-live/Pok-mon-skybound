#ifndef GUARD_BATTLE_TEST_RUNNER_H
#define GUARD_BATTLE_TEST_RUNNER_H

bool8 IsMultibattleTest(void);

#endif
