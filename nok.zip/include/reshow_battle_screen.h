#ifndef GUARD_RESHOW_BATTLE_SCREEN_H
#define GUARD_RESHOW_BATTLE_SCREEN_H

void ReshowBattleScreenDummy(void);
void ReshowBattleScreenAfterMenu(void);
void ReshowBlankBattleScreenAfterMenu(void);
void CreateBattlerSprite(u32 battler);

#endif // GUARD_RESHOW_BATTLE_SCREEN_H
