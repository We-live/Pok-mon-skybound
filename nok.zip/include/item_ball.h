#ifndef GUARD_ITEM_BALL_H
#define GUARD_ITEM_BALL_H

void GetItemBallIdAndAmountFromTemplate(void);

#endif //GUARD_ITEM_BALL_H
