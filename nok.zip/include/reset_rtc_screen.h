#ifndef GUARD_RESET_RTC_SCREEN_H
#define GUARD_RESET_RTC_SCREEN_H

extern const struct SpritePalette gSpritePalette_Arrow;
extern const struct SpriteTemplate gSpriteTemplate_Arrow;

void CB2_InitResetRtcScreen(void);

#endif // GUARD_RESET_RTC_SCREEN_H
