#ifndef GUARD_BATTLE_TENT_H
#define GUARD_BATTLE_TENT_H

bool8 InSlateportBattleTent(void);

#endif //GUARD_BATTLE_TENT_H
