#ifndef GUARD_IO_REG_H
#define GUARD_IO_REG_H

extern const u16 gOverworldBackgroundLayerFlags[];
extern const u16 gOrbEffectBackgroundLayerFlags[];

#endif // GUARD_IO_REG_H
