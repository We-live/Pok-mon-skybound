#ifndef GUARD_BERRY_TAG_SCREEN_H
#define GUARD_BERRY_TAG_SCREEN_H

void DoBerryTagScreen(void);

#endif // GUARD_BERRY_TAG_SCREEN_H
