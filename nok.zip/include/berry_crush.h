#ifndef GUARD_BERRY_CRUSH_H
#define GUARD_BERRY_CRUSH_H

#include "main.h"

void StartBerryCrush(MainCallback exitCallback);

#endif // GUARD_BERRY_CRUSH_H
