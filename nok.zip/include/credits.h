#ifndef GUARD_CREDITS_H
#define GUARD_CREDITS_H

extern bool8 gHasHallOfFameRecords;

void CB2_StartCreditsSequence(void);

#endif // GUARD_CREDITS_H
