#ifndef GUARD_BATTLE_END_TURN
#define GUARD_BATTLE_END_TURN

u32 DoEndTurnEffects(void);

#endif // GUARD_BATTLE_END_TURN

