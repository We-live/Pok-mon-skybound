#ifndef GUARD_CONTESTPAINTING_H
#define GUARD_CONTESTPAINTING_H

void SetContestWinnerForPainting(int contestWinnerId);
void CB2_ContestPainting(void);

#endif
