//
// Created by scott on 10/21/2017.
//

#ifndef GUARD_TRADER_H
#define GUARD_TRADER_H

void DecorationItemsMenuAction_Trade(u8 taskId);
void ExitTraderMenu(u8 taskId);
void TraderSetup(void);
void Trader_ResetFlag(void);

#endif //GUARD_TRADER_H
