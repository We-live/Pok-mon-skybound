#ifndef GUARD_TRAINER_REMATCH_H
#define GUARD_TRAINER_REMATCH_H

#include "constants/rematches.h"

void UpdateGymLeaderRematch(void);

#endif //GUARD_TRAINER_REMATCH_H
