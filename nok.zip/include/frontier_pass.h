#ifndef GUARD_FRONTIER_PASS_H
#define GUARD_FRONTIER_PASS_H

void ShowFrontierPass(void (*callback)(void));
void CB2_ReshowFrontierPass(void);

#endif // GUARD_FRONTIER_PASS_H
