#ifndef GUARD_EXPANSION_INTRO_H
#define GUARD_EXPANSION_INTRO_H

#if EXPANSION_INTRO == TRUE
void CB2_ExpansionIntro(void);
void Task_HandleExpansionIntro(u8 taskId);
#endif

#endif /* GUARD_EXPANSION_INTRO_H */
