#ifndef GUARD_MIRAGE_TOWER_H
#define GUARD_MIRAGE_TOWER_H

void ClearMirageTowerPulseBlendEffect(void);
void ClearMirageTowerPulseBlend(void);
void TryStartMirageTowerPulseBlendEffect(void);

#endif // GUARD_MIRAGE_TOWER_H
