#ifndef GUARD_CONFIG_CONTEST_H
#define GUARD_CONFIG_CONTEST_H

// Move data settings
#define C_UPDATED_MOVE_CATEGORIES   GEN_LATEST // Updates contest category.
#define C_UPDATED_MOVE_EFFECTS      GEN_LATEST // Updates contest effects.

#endif // GUARD_CONFIG_CONTEST_H
