#ifndef GUARD_SLOT_MACHINE_H
#define GUARD_SLOT_MACHINE_H

void PlaySlotMachine(u8 machineId, MainCallback exitCallback);

#endif // GUARD_SLOT_MACHINE_H
