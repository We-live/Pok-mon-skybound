#ifndef GUARD_FIELD_SPECIAL_SCENE_H
#define GUARD_FIELD_SPECIAL_SCENE_H

void ExecuteTruckSequence(void);
void EndTruckSequence(u8 taskId);
void FieldCB_ShowPortholeView(void);

#endif // GUARD_FIELD_SPECIAL_SCENE_H
