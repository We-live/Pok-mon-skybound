#ifndef GUARD_TITLE_SCREEN_H
#define GUARD_TITLE_SCREEN_H

extern const u16 gTitleScreenAlphaBlend[64];

void CB2_InitTitleScreen(void);

#endif // GUARD_TITLE_SCREEN_H
