#ifndef GUARD_CRT0_H
#define GUARD_CRT0_H

extern u32 IntrMain[];

extern void ReInitializeEWRAM();

#endif //GUARD_CRT0_H
