#ifndef GUARD_LANDMARK_H
#define GUARD_LANDMARK_H

const u8 *GetLandmarkName(mapsec_u8_t mapSection, u8 id, u8 count);

#endif // GUARD_LANDMARK_H
