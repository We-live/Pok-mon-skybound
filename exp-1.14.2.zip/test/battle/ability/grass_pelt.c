#include "global.h"
#include "test/battle.h"

TO_DO_BATTLE_TEST("TODO: Write Grass Pelt (Ability) test titles")
