#include "global.h"
#include "test/battle.h"

// Tests for Chilling Neigh are handled in test/battle/ability/moxie.c
