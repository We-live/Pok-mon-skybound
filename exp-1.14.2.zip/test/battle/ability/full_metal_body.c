#include "global.h"
#include "test/battle.h"

// Tests for Full Metal Body are handled in test/battle/ability/clear_body.c
