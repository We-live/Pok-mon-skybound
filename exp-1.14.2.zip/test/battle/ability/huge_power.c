#include "global.h"
#include "test/battle.h"

TO_DO_BATTLE_TEST("TODO: Write Huge Power (Ability) test titles")
