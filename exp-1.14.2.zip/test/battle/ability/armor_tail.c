#include "global.h"
#include "test/battle.h"

// Tests for Armor Tail are handled in test/battle/ability/dazzling.c
