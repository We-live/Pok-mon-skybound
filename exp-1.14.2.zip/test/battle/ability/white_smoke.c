#include "global.h"
#include "test/battle.h"

// Tests for White Smoke are handled in test/battle/ability/clear_body.c
