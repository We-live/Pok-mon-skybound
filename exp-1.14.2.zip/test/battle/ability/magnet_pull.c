#include "global.h"
#include "test/battle.h"

TO_DO_BATTLE_TEST("TODO: Write Magnet Pull (Ability) test titles")
