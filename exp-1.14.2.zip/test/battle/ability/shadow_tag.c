#include "global.h"
#include "test/battle.h"

TO_DO_BATTLE_TEST("TODO: Write Shadow Tag (Ability) test titles")
