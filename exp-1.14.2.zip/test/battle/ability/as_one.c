#include "global.h"
#include "test/battle.h"

// Tests for the individual ability effects are handled in the following times:
// - Unnerve: test/battle/ability/unnerve.c
// - Chilling Neigh: test/battle/ability/chilling_neigh.c
// - Grim Neigh: test/battle/ability/grim_neigh.c
