#include "global.h"
#include "test/battle.h"

TO_DO_BATTLE_TEST("TODO: Write Guts (Ability) test titles")
