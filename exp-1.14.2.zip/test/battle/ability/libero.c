#include "global.h"
#include "test/battle.h"

// Tests for Libero are handled in test/battle/ability/protean.c
