#include "global.h"
#include "test/battle.h"

// Tests for Lingering Aroma are handled in test/battle/ability/mummy.c
