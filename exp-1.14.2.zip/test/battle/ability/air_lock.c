#include "global.h"
#include "test/battle.h"

// Tests for Air Lock are handled in test/battle/ability/cloud_nine.c
