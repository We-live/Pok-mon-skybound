#include "global.h"
#include "test/battle.h"

TO_DO_BATTLE_TEST("TODO: Write Rock Head (Ability) test titles")
