#include "global.h"
#include "test/battle.h"

TO_DO_BATTLE_TEST("TODO: Write Natural Cure (Ability) test titles")
