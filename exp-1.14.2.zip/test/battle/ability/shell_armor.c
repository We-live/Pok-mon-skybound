#include "global.h"
#include "test/battle.h"

// Tests for Shell Armor are handled in test/battle/ability/battle_armor.c
