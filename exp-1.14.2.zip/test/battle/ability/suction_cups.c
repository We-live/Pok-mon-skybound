#include "global.h"
#include "test/battle.h"

TO_DO_BATTLE_TEST("TODO: Write Suction Cups (Ability) test titles")
