#include "global.h"
#include "test/battle.h"

TO_DO_BATTLE_TEST("TODO: Write Teravolt (Ability) test titles")
