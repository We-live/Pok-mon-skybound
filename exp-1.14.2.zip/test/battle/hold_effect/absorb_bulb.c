#include "global.h"
#include "test/battle.h"

TO_DO_BATTLE_TEST("TODO: Write Absorb Bulb (Hold Effect) test titles")
