#include "global.h"
#include "test/battle.h"

TO_DO_BATTLE_TEST("TODO: Write Amulet Coin (Hold Effect) test titles")
