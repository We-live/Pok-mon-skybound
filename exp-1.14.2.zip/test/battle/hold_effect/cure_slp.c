#include "global.h"
#include "test/battle.h"

 // Tests for Chesto Berry are handled in test/battle/hold_effect/cure_status.c
