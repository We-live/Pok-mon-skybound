#include "global.h"
#include "test/battle.h"

TO_DO_BATTLE_TEST("TODO: Write Douse, Shock, Burn and Chill Drive (Hold Effect) test titles")
