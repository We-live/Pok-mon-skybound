#include "global.h"
#include "test/battle.h"

 // Tests for Aspear Berry are handled in test/battle/hold_effect/cure_status.c
