#include "global.h"
#include "test/battle.h"

TO_DO_BATTLE_TEST("TODO: Write Smoke Ball (Hold Effect) test titles")
