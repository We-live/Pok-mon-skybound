# Template

```md
## How to update
- If you haven't set up a remote, run the command `git remote add RHH https://github.com/rh-hideout/pokeemerald-expansion`.
- Once you have your remote set up, run the command `git pull RHH expansion/1.Y.Z`.
```

## 🌋 *REFACTORS* 🌋
📜 = Uses a migration script.
* N/A

## 💥 *Hardlock/Softlock/Crash/Compiling fixes* 💥
* N/A

## 🧬 General 🧬
### Added
* N/A
### Changed
* N/A
### Fixed
* N/A

## ✨ Feature Branches ✨
### ***TheXaman's Debug Menu***:
#### Added
* N/A
#### Changed
* N/A
#### Fixed
* N/A
### ***TheXaman's HGSS Pokédex Plus***:
#### Added
* N/A
#### Changed
* N/A
#### Fixed
* N/A
### ***SBird/Karathan's Dynamic Multichoices***:
#### Added
* N/A
#### Changed
* N/A
#### Fixed
* N/A
### ***ghoulslash's Saveblock Cleansing***:
#### Added
* N/A
#### Changed
* N/A
#### Fixed
* N/A
### ***merrp/aarant's Followers***
#### Added
* N/A
#### Changed
* N/A
#### Fixed
* N/A

## 🐉 Pokémon 🐉
### Added
* N/A
### Changed
* N/A
### Fixed
* N/A

## ⚔️ Battle General ⚔️ ##
### Added
* N/A
### Changed
* N/A
### Fixed
* N/A

## 🤹 Moves 🤹
### Added
* N/A
### Changed
* N/A
### Fixed
* N/A

## 🎭 Abilities 🎭
### Added
* N/A
### Changed
* N/A
### Fixed
* N/A

## 🧶 Items 🧶
### Added
* N/A
### Changed
* N/A
### Fixed
* N/A

## 🤖 Battle AI 🤖
### Added
* N/A
### Changed
* N/A
### Fixed
* N/A

## 🧹 Other Cleanup 🧹
### Added
* N/A
### Changed
* N/A
### Fixed
* N/A

## 🧪 Test Runner 🧪
### Added
* N/A
### Changed
* N/A
### Fixed
* N/A

## 📚 Documentation 📚
### Added
* N/A
### Changed
* N/A
### Fixed
* N/A

## 📦 Branch Synchronisation 📦
### pret's base pokeemerald
* N/A
### merrp/aarant's followers
* N/A


## New Contributors
* N/A

**Full Changelog**: https://github.com/rh-hideout/pokeemerald-expansion/compare/expansion/1.Y.Z...expansion/1.Y.Z

<!--Last PR: ____-->
<!--Used to keep track of the last PR merged in case new ones come in before the changelog is done.-->
