# Fedora instructions
## Installing dependencies
Open a terminal and run the following command from the command line:
```console
sudo dnf install gcc g++ arm-none-eabi-binutils-cs arm-none-eabi-gcc-cs arm-none-eabi-newlib git libpng-devel python3
```
