# Ubuntu instructions
## Installing dependencies
Open a terminal and run the following command from the command line:
```console
sudo apt install build-essential binutils-arm-none-eabi gcc-arm-none-eabi libnewlib-arm-none-eabi git libpng-dev python3
```
