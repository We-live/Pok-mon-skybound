# Instructions for other distributions
1. Try to find the required software in its repositories:
    - `gcc`
    - `g++`
    - `arm-none-eabi-gcc`
    - `arm-none-eabi-binutils`
    - `arm-none-eabi-newlib`
    - `make`
    - `git`
    - `libpng-dev`
    - `python3`
