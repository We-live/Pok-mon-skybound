# Arch Linux instructions
## Installing dependencies
Run the following command from the command line:
```console
sudo pacman -S base-devel arm-none-eabi-binutils arm-none-eabi-gcc arm-none-eabi-newlib git libpng python
```
