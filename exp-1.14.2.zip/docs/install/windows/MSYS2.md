# msys2
Don't, just don't.
Currently doesn't work on current Expansion versions.
This is a bug from upstream pret `pokeemerald`.
